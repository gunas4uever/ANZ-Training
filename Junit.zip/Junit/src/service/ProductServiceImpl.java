package service;

import dao.productDao;
import domain.Product;

public class ProductServiceImpl implements productService{

	
	productDao dao;

	public ProductServiceImpl(productDao dao2) {
		 this.dao = dao2;
	}

	@Override
	public Product ViewProduct(int id) {
		Product p =  dao.ViewProduct(1);
		double currprice = p.getPrice();
		
		if(currprice > 1000){
			currprice = currprice  -(0.10 *  currprice);
		}
		p.setPrice(currprice);
		
		return p;
	}
	
	
}
