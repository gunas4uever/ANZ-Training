package service;

import domain.Product;

public interface productService {

	
	Product ViewProduct(int id);
}
