package dao;

import dao.productDao;
import domain.Product;

public class ProductDaoImpl implements productDao{

	
	productDao dao;

	@Override
	public Product ViewProduct(int id) {
		 
		
		return  new Product(1,"abc",1200.00);
	}
	
	
}
