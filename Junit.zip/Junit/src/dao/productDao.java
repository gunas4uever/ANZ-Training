package dao;

import domain.Product;

public interface productDao {

	Product ViewProduct(int i);

}
