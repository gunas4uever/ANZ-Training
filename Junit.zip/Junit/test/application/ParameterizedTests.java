package application;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.ParametersSuppliedBy;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class ParameterizedTests {

	Calculator cal;
	
	private int numberA;
	private int numberB;
	
	@Before
	public void init(){
		cal = new Calculator();
	}
	
	public  ParameterizedTests( int numberA,  int numberB){
		this.numberA = numberA;
		this.numberB = numberB;		
	}
	
		
	@Parameters
	public static Collection<Object[]>  data(){
		Object[][] data =  new Object[][]{{1,2},{5,3},{121,4}};
		return   Arrays.asList(data);
	}
	
	@Test
	public  void testAddition( ){
		assertEquals(numberA + numberB, cal.add(numberA,numberB));
	}
}
