package hamcrest;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Test;
public class MatcheTest {

	@Test
	public void testChained(){
		assertThat(123,not(is(345)));
	}
}
