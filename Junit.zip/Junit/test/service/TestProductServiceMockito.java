package service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;

import dao.productDao;
import domain.Product;
import junit.framework.Assert;

public class TestProductServiceMockito {

	productService service;
	productDao daoMock;
	
	@Before
	public void init(){
		daoMock = mock(productDao.class);
		service = new ProductServiceImpl(daoMock);
	}
	
	
	@Test
	public void testViewProduct(){
		
		Product p = new Product(1,"abcFromMock",2000.00);
		when(daoMock.ViewProduct(1)).thenReturn(p);

		Product p1 = service.ViewProduct(1);
		Assert.assertEquals(1800.00, p1.getPrice());
		verify(daoMock);
	}
	
	
}  

