$(document).ready(function () {
    console.log("---- dom Ready");
    $('.vacation').on('click', 'button', function (e) {
        var vacation = $(this).closest('.vacation');
        var amount = vacation.data('price');
        var price = $(`
    <p>&#8377;${amount} per ticket</p>
     Numner of Tickets: <input class='quantity' value='1' type="number"/> <br/>
    <span class='total'>Total Amount:&#8377;${amount}</span>
    `);

        $(this).closest('.vacation').append(price);
        $(this).remove('button');

        // console.log('Amount is '+amount);
    });

    $('.vacation').on('keyup change', '.quantity', function (e) {
        var qua=$(this).val();
        var price = $(this).closest('.vacation').data('price');
      $(this).parent().parent().find('.total').text(price * qua);
    });


   $('#filters').on('click','.onsale-filter',function(e){
     $('.bg-success').removeClass('bg-success');
    $('.vacation').filter('.onsale').addClass('bg-success');

   });

   $('#filters').on('click','.expiring-filter',function(e){
     $('.bg-success').removeClass('bg-success');
    $('.vacation').filter('.expiring').addClass('bg-success');

   });
    //   $('.btn-primary').click(function(e){
    //        // create a button component
    //        var btn=$('<button> New Button</button>');

    //        var d1=$('.d1');
    //        var d2=$('.d2');
    //        var d3=$('.d3');
    //        var d4=$('.d4');

    //        //console.log(d1);
    //        d1.css('background-color','red');
    //        d2.css('background-color','green');
    //        d3.css('background-color','yellow');
    //        d4.css('background-color','pink');

    //        d4.append(btn);



    //   })


    //  $('.d1 .btn-primary').click(function(){
    //     console.log("--- Div Button Clicked");
    //     var header1=$('<h3>Hello</h3>');
    //     $('.d2').append(header1);

    //     console.log(header1);


    //  }) ;


});