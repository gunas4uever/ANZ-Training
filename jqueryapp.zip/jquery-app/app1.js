$(document).ready(function () {

    // doc filter
    $('#filters').on('click', '.filter-doc', function (e) {
        $('bg-success').removeClass();
        $('.links').filter('.docLink').addClass('bg-success');
    })

    //pdf filter
    $('#filters').on('click', '.filter-pdf', function (e) {
        $('.bg-success').removeClass();
        $('.links').filter('.pdfLink').addClass('bg-success');
    })
});