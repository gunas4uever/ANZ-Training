/**
 * http://usejsdoc.org/
 */

console.log('this script will get loaded dynamically to browser..');