/**
 * http://usejsdoc.org/
 */

//function reflect() {
//	console.dir(arguments);
//	return arguments["0"];
//}
//
//console.log(reflect(12,13,14));

// JS based on ECMA 6

