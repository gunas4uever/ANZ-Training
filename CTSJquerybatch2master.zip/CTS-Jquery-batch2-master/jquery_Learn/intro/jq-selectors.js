/**
 * http://usejsdoc.org/
 */


// way-1
//$(selector:filter)
// way-2
//$(selector).filter(func/css);

$(function(){

	
	// $("#lastname").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $(".intro").css({'border':'1px solid red','background-color':'yellow'});
	// $(".intro,#lastname").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("h1").css({'border':'1px solid red','background-color':'yellow'});
	// $("h1,p").css({'border':'1px solid red','background-color':'yellow'});
	// $("p:first").css({'border':'1px solid red','background-color':'yellow'});
	// $("p:last").css({'border':'1px solid red','background-color':'yellow'});
	// $("p:even").css({'border':'1px solid red','background-color':'yellow'});
	
	
	// $("tr:even").css({'border':'1px solid red','background-color':'yellow'});
	// $("tr:odd").css({'border':'1px solid red','background-color':'yellow'});
	
	// $("p:first-child").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("p:first-of-type").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("p:last-child").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("p:last-of-type").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("li:nth-child(1)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("li:nth-of-type(2)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("li:nth-last-of-type(2)").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("b:only-child").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("h3:only-of-type").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("div>p").css({'border':'1px solid red','background-color':'yellow'});
	// $("div p").css({'border':'1px solid red','background-color':'yellow'});
	// $("ul+h3").css({'border':'1px solid red','background-color':'yellow'});
	// $("ul~table").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("ul li:eq(0)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("ul li:gt(1)").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $(":header").css({'border':'1px solid red','background-color':'yellow'});
	// $(":header:not(h1)").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	
	// based on element's content
	// $(":contains(Nag)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("div:has(p)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $(":empty").css({'border':'1px solid red','background-color':'yellow'});
	
	// $(":parent").css({'border':'1px solid red','background-color':'yellow'});
	// $(":root").css({'border':'1px solid red','background-color':'yellow'});
	
	
	// based on element's attributes
	
	// $("p:lang(it)").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("[id]").css({'border':'1px solid red','background-color':'yellow'});
	// $("[id=my-Address]").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("[id!=my-Address]").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("[id$=ess]").css({'border':'1px solid
	// red','background-color':'yellow'});
	// $("[id^=m]").css({'border':'1px solid red','background-color':'yellow'});
	// $("[title~=beautiful]").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	// $("[id|=my]").css({'border':'1px solid
	// red','background-color':'yellow'}); // id="my-XXXX"
	// $("[id*=s]").css({'border':'1px solid red','background-color':'yellow'});
	
	
	// Form based Selectors and Filters
	// $(":input").css({'border':'1px solid red','background-color':'yellow'});
	// $(":text").css({'border':'1px solid red','background-color':'yellow'});
	// $(":disabled").css({'border':'1px solid
	// red','background-color':'yellow'});
	
	//$("*").css({'border':'1px solid red','background-color':'yellow'});  
	
	
	
	
	
});

