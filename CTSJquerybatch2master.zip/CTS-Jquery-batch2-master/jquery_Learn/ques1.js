/**
 * http://usejsdoc.org/
 */

//function reflect(arg1,arg2){
//	console.log('func called...');
//	return arguments[0]+" "+arguments[1];
//}
//
//console.log(reflect(12,13));