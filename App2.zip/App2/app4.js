var color='globar color';
var Vehicle = Backbone.Model.extend({
    color: 'blue',
    initialize: function () {
        console.log('-- in constructor ' + this.color);
    },
    disp:function(){
        console.log('--> in disp: '+this.color);
    },
});

var car = new Vehicle();
console.log(car.get('color'));
console.log(car.get('type'));
car.disp();
