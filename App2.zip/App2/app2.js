var Vehicle = Backbone.Model.extend({
    prop1: '1',
    initialize:function(p1){
        this.getvalues(p1);
    },
    getvalues:function(p1){
        console.log('Vaue: '+this.prop1+' with comment: '+p1);
    }
});
var v1 = new Vehicle('AT Object Creation Level V1');
var v2 = new Vehicle('AT Object Creation Level V2');
v1.prop1='2000';
// v1:{
//     prop1:'100'
// };
//console.log(v1.prop1);
//console.log(v2.prop1);
v1.getvalues('on top of v1');
v2.getvalues('on top of v2');
