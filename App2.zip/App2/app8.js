// var myModel = new Backbone.Model();
// myModel.set('content', '<p>this is some content</p>');

// var myView = new Backbone.View({
//     model: myModel,
//     className: 'model-object',
// });


// console.log(myView.model.toJSON());

// precompile the template
var V = Backbone.View.extend({
    el: '#d1',
    render: function () {
        var data = { lat:-27, lon: 153 };
        this.$el.html(_.template('<%= lat %>', data));
        return this;
    }
});

var v = new V();
v.render();
