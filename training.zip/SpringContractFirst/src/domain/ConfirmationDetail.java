package domain;

import java.util.Date;

public class ConfirmationDetail {
private int bookId;
private double bookPrice;
private String confId;
private Date DateOrdered;



public ConfirmationDetail(int bookId, double bookPrice, String confId, Date dateOrdered) {
	super();
	this.bookId = bookId;
	this.bookPrice = bookPrice;
	this.confId = confId;
	DateOrdered = dateOrdered;
}


public ConfirmationDetail() {
	super();
	// TODO Auto-generated constructor stub
}


public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}
public double getBookPrice() {
	return bookPrice;
}
public void setBookPrice(double bookPrice) {
	this.bookPrice = bookPrice;
}
public String getConfId() {
	return confId;
}
public void setConfId(String confId) {
	this.confId = confId;
}
public Date getDateOrdered() {
	return DateOrdered;
}
public void setDateOrdered(Date dateOrdered) {
	DateOrdered = dateOrdered;
}



}
