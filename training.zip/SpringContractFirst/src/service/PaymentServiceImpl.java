package service;

import java.util.Date;

import org.springframework.stereotype.Component;

import domain.BookDetail;
import domain.ConfirmationDetail;

@Component
public class PaymentServiceImpl implements PaymentService{

	@Override
	public ConfirmationDetail doPayment(BookDetail bd) {
		// TODO Auto-generated method stub
		return new ConfirmationDetail
				(bd.getId(), bd.getPrice(), "ABC123", new Date());
	}

}
