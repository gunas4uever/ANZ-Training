package service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.samples.spring.abc.bookns.BookRequest;
import com.samples.spring.abc.bookns.BookResponse;

import domain.BookDetail;
import domain.ConfirmationDetail;

@Endpoint
public class PaymentEndPoint {
    @Autowired
	PaymentService service;
	
    @PayloadRoot(localPart="bookRequest",
    		namespace="http://www.abc.spring.samples.com/bookns")
	public @ResponsePayload BookResponse doPayment(@RequestPayload BookRequest req)
	{
		BookDetail book = new BookDetail(req.getId(),
				req.getName(),req.getPrice().doubleValue());
		
		
		ConfirmationDetail conf = service.doPayment(book);
		BookResponse resp = new BookResponse();
		resp.setId(conf.getBookId());
		resp.setConfirmationId(conf.getConfId());
		resp.setAmount(new BigDecimal(conf.getBookPrice()));
		resp.setOrderDate(conf.getDateOrdered());
				
				return resp;
	}
	
	
}
