package service;

import domain.BookDetail;
import domain.ConfirmationDetail;

public interface PaymentService {
ConfirmationDetail doPayment(BookDetail bd);
}
