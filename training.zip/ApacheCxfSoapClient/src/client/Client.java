package client;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import services.ImageData;
import services.Order;
import services.OrderProcess;
import services.OrderProcessImplService;
import services.SaveOrderImage;

public class Client {

	public static void main(String args[]){
		OrderProcessImplService obj = new OrderProcessImplService();
		OrderProcess service = obj.getOrderProcessImplPort();
		Order o = new Order();
		o.setCustomerId("ddd");o.setItemId("I001");o.setQty(100);o.setPrice(300.00);
		
		String confId =  service.processOrder(o);
		System.out.println(confId);
		new Client().saveOrder();
		
		
	}
	
	
	public void saveOrder(){
		OrderProcessImplService obj = new OrderProcessImplService();
		OrderProcess service = obj.getOrderProcessImplPort();
		ImageData img = new ImageData();
		img.setName("abc.png");
		DataSource d = new FileDataSource("C:\\Users\\363629\\Desktop\\folder\\abc.png");
		img.setMyImage(new DataHandler(d));

		service.saveOrderImage(img);
	}
	
}
