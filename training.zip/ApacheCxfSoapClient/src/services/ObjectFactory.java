
package services;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the services package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SaveOrderImage_QNAME = new QName("http://services/", "saveOrderImage");
    private final static QName _ProcessOrderResponse_QNAME = new QName("http://services/", "processOrderResponse");
    private final static QName _SaveOrderImageResponse_QNAME = new QName("http://services/", "saveOrderImageResponse");
    private final static QName _ProcessOrder_QNAME = new QName("http://services/", "processOrder");
    private final static QName _ImageData_QNAME = new QName("http://services/", "ImageData");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: services
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProcessOrder }
     * 
     */
    public ProcessOrder createProcessOrder() {
        return new ProcessOrder();
    }

    /**
     * Create an instance of {@link ProcessOrderResponse }
     * 
     */
    public ProcessOrderResponse createProcessOrderResponse() {
        return new ProcessOrderResponse();
    }

    /**
     * Create an instance of {@link SaveOrderImageResponse }
     * 
     */
    public SaveOrderImageResponse createSaveOrderImageResponse() {
        return new SaveOrderImageResponse();
    }

    /**
     * Create an instance of {@link ImageData }
     * 
     */
    public ImageData createImageData() {
        return new ImageData();
    }

    /**
     * Create an instance of {@link SaveOrderImage }
     * 
     */
    public SaveOrderImage createSaveOrderImage() {
        return new SaveOrderImage();
    }

    /**
     * Create an instance of {@link Order }
     * 
     */
    public Order createOrder() {
        return new Order();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveOrderImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services/", name = "saveOrderImage")
    public JAXBElement<SaveOrderImage> createSaveOrderImage(SaveOrderImage value) {
        return new JAXBElement<SaveOrderImage>(_SaveOrderImage_QNAME, SaveOrderImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services/", name = "processOrderResponse")
    public JAXBElement<ProcessOrderResponse> createProcessOrderResponse(ProcessOrderResponse value) {
        return new JAXBElement<ProcessOrderResponse>(_ProcessOrderResponse_QNAME, ProcessOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveOrderImageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services/", name = "saveOrderImageResponse")
    public JAXBElement<SaveOrderImageResponse> createSaveOrderImageResponse(SaveOrderImageResponse value) {
        return new JAXBElement<SaveOrderImageResponse>(_SaveOrderImageResponse_QNAME, SaveOrderImageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services/", name = "processOrder")
    public JAXBElement<ProcessOrder> createProcessOrder(ProcessOrder value) {
        return new JAXBElement<ProcessOrder>(_ProcessOrder_QNAME, ProcessOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImageData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services/", name = "ImageData")
    public JAXBElement<ImageData> createImageData(ImageData value) {
        return new JAXBElement<ImageData>(_ImageData_QNAME, ImageData.class, null, value);
    }

}
