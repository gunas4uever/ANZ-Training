package test;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.security.wss4j.Wss4jSecurityFaultException;
import org.springframework.ws.soap.security.wss4j.Wss4jSecurityInterceptor;

import com.samples.spring.abc.bookns.BookRequest;
import com.samples.spring.abc.bookns.BookResponse;

import domain.BookDetail;

@ContextConfiguration("classpath:client-config.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class TestClient {

	@Autowired
	WebServiceTemplate wsTemplate;
	
	@Autowired
	Wss4jSecurityInterceptor security;
	
	@Test
	public void invokeService(){
		
		security.setSecurementUsername("system");
		security.setSecurementPassword("123456");
		
		BookDetail b = new BookDetail(1,"java book", 1000.00);
		BookRequest request = new BookRequest();
		request.setId(b.getId());
		request.setName(b.getName());
		request.setPrice(new BigDecimal(b.getPrice()));
		
		BookResponse response = (BookResponse) wsTemplate.marshalSendAndReceive(request);
		
		assertNotNull(response);
		assertEquals("ABC123",response.getConfirmationId());
		
	}
}
