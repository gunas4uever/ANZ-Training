package test;

import org.easymock.EasyMock;
import org.eclipse.core.internal.runtime.Product;
import org.junit.Before;
import org.junit.Test;

import dao.BookDAO;
import junit.framework.Assert;
import model.Book;
import service.BookService;
import service.BookServiceImpl;

public class TestClass {

	BookService service;
	BookDAO daoMock;
	
	@Before
	public void init(){
		daoMock = EasyMock.createMock(BookDAO.class);
		service = new BookServiceImpl(daoMock);
	}
	
	@Test
	public void testViewproduct(){
		Book b = new Book();
		//EasyMock.expect(daoMock.getRecord(b)).andReturn();
		EasyMock.replay(daoMock);
		
		
		/*Product p1 = service.ViewProduct(1);
		Assert.assertEquals(1800.00, p1.getPrice());
		EasyMock.verify(daoMock);*/
	}
	
}
