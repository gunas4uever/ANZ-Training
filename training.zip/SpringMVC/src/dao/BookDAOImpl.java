package dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import model.Book;

@Repository
public class BookDAOImpl implements BookDAO{

private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public BookDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public void insert(Book b) {

		String query = "insert into books(BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR ) "
				+ "values(?,?,?,?,?,?)";
		
		//String query1 = "insert into REVIEWS(ID, RATING, COMMENTS, BOOKID ) values(?,?,?,?)";
		jdbcTemplate.update(query,  new Object[] { b.getBookId(),b.getTitle(),b.getLanguage(),b.getNoOfPages(),
				b.getStatus(),b.getAuthor()});
		
	}

	@Override
	public List<Book> getRecord(Book b) {
		//String query = "select BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR from books";
		
		//return (List<Book>)jdbcTemplate.query(query,Book.class);
		
		String query="select * from books";
				return (List<Book>)jdbcTemplate.query(query,new BeanPropertyRowMapper(Book.class));
		
	}

}
