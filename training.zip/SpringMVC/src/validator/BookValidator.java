package validator;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.metadata.BeanDescriptor;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

public class BookValidator implements Validator{

	public void validate(Object u, Errors errors){
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bookId", "bookId.required", "bookId should not be blank");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "title.required", "title should not be empty");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "author", "author.required", "author should not be empty");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "language", "language.required", "language should not be empty");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "noOfPages", "noOfPages.required", "noOfPages should not be empty");
	}

	@Override
	public BeanDescriptor getConstraintsForClass(Class<?> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T unwrap(Class<T> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validate(T arg0, Class<?>... arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validateProperty(T arg0, String arg1, Class<?>... arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validateValue(Class<T> arg0, String arg1, Object arg2, Class<?>... arg3) {
		// TODO Auto-generated method stub
		return null;
	}

}
