package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.BookDAO;
import model.Book;

@Service 
public class BookServiceImpl implements BookService{

	
	@Autowired
	private BookDAO bookDAO;
	
	 public BookServiceImpl(BookDAO daoMock) {
		this.bookDAO = daoMock;
	}

	@Override
	public void insert(Book b) {
			bookDAO.insert(b);	
	}

	@Override
	public List<Book> getRecord(Book book) {
		return bookDAO.getRecord(book);	
	
		
	}

}
