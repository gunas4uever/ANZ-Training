package controllers;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import exception.CustomGenericException;

//@ControllerAdvice
public class GlobalExceptionController {
	
	@ExceptionHandler(CustomGenericException.class)
	public ModelAndView handleCustomException(CustomGenericException e){
		ModelAndView model = new ModelAndView("generror");
		model.addObject("errcode", e.getErrCode());
		model.addObject("errMsg", e.getErrMsg());
		return model;
		
	}
	
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception e){
		ModelAndView model = new ModelAndView("generror");
		//model.addObject("errcode", e.getErrCode());
		model.addObject("errMsg", "this is exception.class");
		return model;
		
	}

}
