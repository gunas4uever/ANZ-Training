package controllers;


import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import exception.CustomGenericException;
import model.Book;
import model.User;
import validator.UserValidator;

@Controller
@RequestMapping("/hello")
public class HelloController {

	@RequestMapping(value = "abc", method =RequestMethod.GET)
	public String printHello()
	{
		return "hello";
	}
	
	
	@RequestMapping(value = "xyz", method =RequestMethod.GET, params="message")
	public String printHello1(@RequestParam String message)
	{
		System.out.println(" in printHello1 "+ message);
		return "hello";
	}
	
	
	@RequestMapping(value = "model", method =RequestMethod.GET 	)
	public String printHello2(Model model)
	{
		Book b = new Book("1","abc","eng","20","available","ppp");
		model.addAttribute("mybook",b);
		return "hello";
	}
	
	
	@RequestMapping(value = "modelview", method =RequestMethod.GET 	)
	public ModelAndView printHello3()
	{
		Book b = new Book("2","def","doc","26","na","fff");
		ModelAndView obj = new ModelAndView();
		obj.addObject("mybook",b);
		obj.setViewName("hello");
		return obj;
	}
	
	
	@RequestMapping(value = "showLogin", method =RequestMethod.GET 	)
	public String showLogin(Model model)
	{
		model.addAttribute("user", new User("",""));
		return "login";
	}
	
	
	@RequestMapping(value = "login", method =RequestMethod.POST 	)
	public String loginSubmit(@ModelAttribute User user, BindingResult result, Model model ) throws CustomGenericException
	{
		
		
		System.out.println(user.getUserName());System.out.println(user.getPassword());
		model.addAttribute("user", user);
		ModelAndView  m;
		UserValidator user1 = new UserValidator();
		user1.validate(user1, result);
		if(result.hasErrors())
			  return "login";
		/*else
			m = new ModelAndView("redirect:/spring/book");*/
		List<User> users = Arrays.asList(new User("abc","pass"), new User("def","pass2"));
		
		if("abc".equals(user.getUserName()) &&  "pass".equals(user.getPassword()) )
		{
			//ModelAndView modd = new ModelAndView("redirect:/spring/book/");
			model.addAttribute("user", users);
			return "redirect:/spring/book/";
		}
		else{
			//result.reject("error", "username  and password not valid");
			//return new ModelAndView("login");
			
			throw new CustomGenericException("1000","Invalid user input");
		}
	}
	
	@RequestMapping(value = "/list", method =RequestMethod.GET 	)
	public ModelAndView listUsers( Model model)
	{
		List<User> users = Arrays.asList(new User("abc","pass"), new User("def","pass2"));
				//model.addAttribute("users",users);
		model.addAttribute("book", new Book());
		
		return new ModelAndView("redirect:/spring/book");
				
	}
	 
	
	/*@RequestMapping(value = "logonn", method =RequestMethod.GET 	)
	public ModelAndView login(@ModelAttribute User user, Model model)
	{
		System.out.println(user.getUserName());System.out.println(user.getPassword());
		model.addAttribute("user", user);
		ModelAndView  m = new ModelAndView("redirect:/spring/book");
		return m;
	}*/
	
	
}
