package controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Book;
import service.BookService;
import validator.BookValidator;

@Controller
@RequestMapping("/book/")
public class BookController {
	
	@Autowired
	private BookService bookService;
	
	@RequestMapping( method =RequestMethod.GET)
	public String home(Model model)
	{
		model.addAttribute("book", new Book());
		return "book";
	}
	
	@RequestMapping(value = "insert", method =RequestMethod.POST)
	public String insertBook(@ModelAttribute Book book, BindingResult result, Model model)
	{
		System.out.println(" inside insert me " + bookService);
		ModelAndView ml;
		BookValidator validator = new BookValidator();
		validator.validate(validator, result);
		if(result.hasErrors())
			ml = new ModelAndView("book");
		else{
			bookService.insert(book);
		}
		
		List<Book> bookList = bookService.getRecord(book);
		model.addAttribute("bookList",bookList);
		return "book";
	}

/*	public BookService getBookService() {
		return bookService;
	}

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}*/
	
	
}
