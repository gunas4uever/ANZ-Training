package model;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

public class Book {
	@NotNull @NotEmpty @NotBlank
	private String  bookId;
	@NotNull @NotEmpty @NotBlank
	private String title;
	@NotNull @NotEmpty @NotBlank
	private String author;
	@NotNull @NotEmpty @NotBlank
	private String language;
	@NotNull @NotEmpty @NotBlank
	private String  noOfPages;
	
	private List<User> user;
	
	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getNoOfPages() {
		return noOfPages;
	}

	public void setNoOfPages(String noOfPages) {
		this.noOfPages = noOfPages;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@NotNull @NotEmpty @NotBlank
	private String status;
	 
	public Book(){}
	
	public Book(String bookId, String title, String language, String noOfPages, String status, String author) {
		 this.bookId=bookId;
		 this.title=title;
		 this.language=language;
		 this.noOfPages=noOfPages;
		 this.status=status;
		 this.author=author;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	 

	 
}