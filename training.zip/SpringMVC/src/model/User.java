package model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

public class User {

	@NotNull @NotEmpty @NotBlank
	private String userName;
	@NotNull @NotEmpty @NotBlank
	private String password;
	
	public User(String userName, String password) {
		 this.userName = userName;
		 this.password = password;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
