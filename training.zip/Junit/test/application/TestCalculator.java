package application;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestCalculator {
	Calculator  c = null;
	
	@BeforeClass
	public static void init1(){
		System.out.println(" method called once before for the class ...");
	}
	
	@Before
	public void init(){
		System.out.println(" init  called ...");
		c  = new Calculator();
	}
	
	@Test
	public void testAdd(){
		//Calculator  c = new Calculator();
		int sum = c.add(3, 4);
		assertEquals(7, sum );
	}
	
	
	@Test
	public void testSubtract(){
		//Calculator  c = new Calculator();
		int sub = c.subtract(16, 4);
		//assertNotSame(unexpected, actual);("not null", c);
		assertEquals(12, sub );
	}
	
	@Test
	public void testMultiply(){
		//Calculator  c = new Calculator();
		int multiply = c.multiply(3, 4);
		assertEquals(12, multiply );
	}
	
	@Test
	public void testDivide(){
		//Calculator  c = new Calculator();
		int divide = c.divide(15, 3);
		assertEquals(5, divide );
	}
	
	
	@After
	public void destry(){
		System.out.println(" destroy called ...");
	}
	
	@AfterClass
	public static void destroy1(){
		System.out.println(" method called once after the class ...");
	}
	
	@Ignore("Not ready to run")
	@Test(expected=ArithmeticException.class)
	public void divisionWithException(){
		
		int i = 1/0;
	}
	
	@Ignore("Not ready to run")
	@Test(timeout=1000)
	public void infinity(){
		while(true);
	}
}
