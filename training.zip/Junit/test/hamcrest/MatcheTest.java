package hamcrest;


public class MatcheTest {

	
	public void chain(){
		
	}
}
