package service;

import org.easymock.EasyMock;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import dao.productDao;
import domain.Product;

public class TestProductService {

	productService service;
	productDao daoMock;
	
	@Before
	public void init(){
		daoMock = EasyMock.createMock(productDao.class);
		service = new ProductServiceImpl(daoMock);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testViewproduct(){
		Product p = new Product(1, "abcFromMock", 2000);
		EasyMock.expect(daoMock.ViewProduct(1)).andReturn(p);
		EasyMock.replay(daoMock);
		
		
		Product p1 = service.ViewProduct(1);
		Assert.assertEquals(1800.00, p1.getPrice());
		EasyMock.verify(daoMock);
	}
	
}
