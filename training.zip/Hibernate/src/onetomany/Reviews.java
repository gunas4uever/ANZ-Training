package onetomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Reviews {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int reviewId;
	private String reviewComment;
	private String author;
	
	@ManyToOne
	@JoinColumn(name="bookId")
	private Book book;
	 
	 public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public Reviews() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reviews(int reviewId, String reviewComment, String author) {
		super();
		this.reviewId = reviewId;
		this.reviewComment = reviewComment;
		this.author = author;
	}
	public String getReviewComment() {
		return reviewComment;
	}
	public void setReviewComment(String reviewComment) {
		this.reviewComment = reviewComment;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Reviews [reviewId=" + reviewId + ", reviewComment=" + reviewComment + ", author=" + author + ", book="
				+ book + "]";
	}
	
	 
	
}
