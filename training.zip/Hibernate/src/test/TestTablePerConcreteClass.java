package test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import model.User;
import singletableperclass.DailyWorker;
import singletableperclass.SalariedWorker;
import singletableperclass.Worker;

public class TestTablePerConcreteClass {

	private static SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new TestTablePerConcreteClass().saveWorker();
		//new TestSingleTablePerClass().saveEmp();
	}

	public void saveWorker()
	{
		Session session = factory.openSession();		
		session.beginTransaction();
		Worker w = new Worker();
		w.setName("Aarush");
		session.save(w);
		
		DailyWorker d = new DailyWorker();
		d.setName("Vishal");
		d.setHourlyRate(1000);
		d.setContractPeriod(100);
		session.save(d);
		
		SalariedWorker s = new SalariedWorker();
		s.setName("mike");
		s.setSalary(10000);
		session.save(s);
		
		session.getTransaction().commit();
		Query query =  session.createQuery("from Worker u ");
		List<Worker> u =query.list();
		u.forEach(System.out::println);
		session.close();
	}
	
	/*public void saveEmp()
	{
		Session session = factory.openSession();		
		session.beginTransaction();
		Emp e1 = new Emp();
		e1.setName("hi");
		Emp e2 = new Emp();
		e2.setName("hi");
		
		Permanent p = new Permanent();
		
		 p.setName("pt");
	     p.setSalary(34123);
	     session.save(e1);
	     session.save(e2);
		session.save(p);
		session.getTransaction().commit();
	}*/
	
}
