package test;

import java.util.Date;
import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import model.User;

public class TestUser {

	private static SessionFactory factory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new TestUser().save();
		
		//new TestUser().getUser();
		//new TestUser().updateUser();
		new TestUser().getAllUsers();
		new TestUser().getFilteredUsers();
		new TestUser().getHQLUsers();
	}
	
	public void save(){
		User u = new User();
		u.setUserName("abc");
		u.setAddress("chn");
		u.setDescription("descrpt");
		u.setJoinDate(new Date());
		
		Session session = factory.openSession();
		session.beginTransaction();
		session.save(u);
		session.getTransaction().commit();
		session.close();
		factory.close();
		
	}
	
	public void getUser(){
		Session session = factory.openSession();
		
		 Session session1 = factory.openSession();
		 System.out.println("User is calling with get()");        
		 User u1 = (User)session1.get(User.class,3);
		 System.out.println("user called with get()");
		 System.out.println("Printing user Id___"+u1.getUserId());        
		 System.out.println("Printing user Name___"+u1.getUserName());
	
		 System.out.println(u1);
		 System.out.println(" ---------------------------------------- ");
		 System.out.println("User is calling with load()");        
		 User u2 = (User)session.load(User.class,1);    
		 System.out.println("user called with load()");
		 System.out.println("Printing user Id___"+u2.getUserId());        
		 System.out.println("Printing user Name___"+u2.getUserName());
		 System.out.println(u2);
		 session.close();
	}
	
	public void updateUser(){
		Session session = factory.openSession();
		
		session.beginTransaction();
		 User u2 = (User)session.get(User.class,1);
		 System.out.println("before  user Name___"+u2.getUserName());
		 u2.setUserName("update u2 --");
		 System.out.println("before save user Name___"+u2.getUserName());
		 session.update(u2);
		 User u = new User();u.setUserName("2 --- ");u.setUserId(1);
		session.merge(u);
		 System.out.println("after save user Name___"+u2.getUserName());
		 
		 
		u2.setDescription("new desc updated");
		 System.out.println("after save user DESC"+u2.getDescription());
		session.getTransaction().commit();
		System.out.println(u2);
		session.close();
		factory.close();
		  
	}
	
	public void removeUser(){
		
		Session session = factory.openSession();
		
		session.beginTransaction();
		 User u2 = (User)session.get(User.class,2);
		 session.delete(u2);
		 session.getTransaction().commit();
		session.close();
	}
	
	public void getAllUsers(){
		System.out.println(" ----------------- getAllUsers -------");
		Session session = factory.openSession();
		Criteria c = session.createCriteria(User.class);
		List<User> u = c.list();
		u.forEach(System.out::println);
		session.close();
		
	}
	
	public void getFilteredUsers(){
		System.out.println(" ----------------- getFiltered -------");
		Session session = factory.openSession();
		Criteria c = session.createCriteria(User.class);
		c.add(Restrictions.eq("userName", "abc"));
		c.add(Restrictions.eq("userId", 2));c.add(Restrictions.eq("description", "descrpt"));
		List<User> u = c.list();
		u.forEach(System.out::println);
		session.close();
		
	}
	
	public void getHQLUsers(){
		System.out.println(" ----------------- getHQLUsers -------");
		Session session = factory.openSession();
		Query query =  session.createQuery("from User u WHERE  u.userName='abc'");
		 
		List<User> u =query.list();
		u.forEach(System.out::println);
		session.close();
		
	}

}
