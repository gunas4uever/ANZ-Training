package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import onetomany.Book;
import onetomany.Reviews;

public class TestOneToMany {
	private static SessionFactory factory 
	= new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args)
	{
		//new TestOneToMany().save();
		
		//new TestOneToMany().getBook();
	}
	
	public void save(){
		Book b = new Book();
		 b.setBookName("india-pakistan");
		
		List<Reviews> l = new ArrayList<Reviews>();
		Reviews r = new Reviews();
		r.setAuthor("che");r.setReviewComment("wonderful");
		r.setBook(b);
		Reviews r1 = new Reviews();
		r.setAuthor("che");r.setReviewComment("not interesting ....");
		r1.setBook(b);
		
		b.setReviews(Arrays.asList(r,r1));
		
		/*r.setAuthor("chetan");r.setReviewComment("wonderful");l.add(r);r = new Reviews();
		r.setAuthor("chetan");r.setReviewComment("good but some how interesting");l.add(r);r = new Reviews();
		r.setAuthor("chetan");r.setReviewComment("not interesting ...."); l.add(r);b.setReviews(l);*/
		Session session = factory.openSession();
		session.beginTransaction();
		session.save(b);
		session.getTransaction().commit();
		session.close();
	}
	public void getBook(){
		Session session = factory.openSession();
		Book u1 = (Book)session.get(Book.class,1);
		 System.out.println(u1.getBookId());
		 
		 System.out.println(u1.getReviews());
		
	}
}
