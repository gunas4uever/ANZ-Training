package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import model.Country;

public class Level2CountryCache {
	private static SessionFactory factory = new Configuration().configure().buildSessionFactory();
public static void main(String[] args) {
	testLevel2Cache();
}
	public static void testLevel2Cache() {
		Session session = factory.openSession();

		Country b1 = (Country)session.get(Country.class, "IN");
		session.close();
		System.out.println(" first time " + b1);
		session = factory.openSession();
		
		Country b1Again =(Country)session.get(Country.class, "IN");
		System.out.println(" After session close " + b1Again);
		session.close();
		
		session = factory.openSession();
		Country b2Again =(Country)session.get(Country.class, "IN");
		System.out.println(" Again After session close "+b2Again);
	
	
	}
}
