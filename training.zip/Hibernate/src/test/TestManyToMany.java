package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import manytomany.Student;
import manytomany.Teacher;
import onetomany.Book;
import onetomany.Reviews;

public class TestManyToMany {
	private static SessionFactory factory 
	= new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args)
	{
		new TestManyToMany().save();
		
		//new TestManyToMany().getBook();
	}
	
	public void save(){
		Student s = new Student();
		s.setName("aaaa");s.setCourse("engg");
		
		 Teacher t = new Teacher();
		 t.setTeacherName("maaa");
		 
		 Teacher t1 = new Teacher();
		 t1.setTeacherName("ssssss");
		 
		 s.getTeacher().add(t);
		 s.getTeacher().add(t1);
		 
		 
		Session session = factory.openSession();
		session.beginTransaction();
		session.save(s);
		session.getTransaction().commit();
		session.close();
	}
	public void getBook(){
		Session session = factory.openSession();
		Book u1 = (Book)session.get(Book.class,1);
		 System.out.println(u1.getBookId());
		 
		 System.out.println(u1.getReviews());
		
	}
}
