package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import model.Country;

public class Level1CountryCache {
	private static SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();

public static void main(String[] args) {
	//saveCountry();
	testLevelOneCache();
}
	public static void testLevelOneCache()
	{
		Session session = factory.openSession();
		
		Country b1 = (Country)session.get(Country.class, "IN");
		System.out.println(b1);
		Country b2 =(Country)session.get(Country.class, "IN");
		Country b3 = (Country)session.get(Country.class, "IN");
		Country b4 =(Country)session.get(Country.class, "IN");
		
	}
	
	
	public static void saveCountry()
	{
		Country c = new Country();
		c.setCode("IN");
		c.setName("INDIA");
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.save(c);
		session.getTransaction().commit();
		session.close();
		factory.close();
		
	}

}
