package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import onetoone.BankDetail;
import onetoone.Customer;

public class TestOneToOne {
	private static SessionFactory factory 
	= new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args)
	{
		Customer c = new Customer();
		c.setName("guna");
		
		BankDetail b = new BankDetail();
		b.setAcctNumber("11111222");b.setBranch("sb");
		c.setBank(b);
		Session session = factory.openSession();
		session.beginTransaction();
		session.save(c);
		session.getTransaction().commit();
		
	}
}
