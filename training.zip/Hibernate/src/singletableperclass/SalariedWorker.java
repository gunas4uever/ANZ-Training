package singletableperclass;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="SW")
public class SalariedWorker extends Worker{
private double salary;

@Override
public String toString() {
	return "SalariedWorker [salary=" + salary + "]";
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}

}
