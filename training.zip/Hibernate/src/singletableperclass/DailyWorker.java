package singletableperclass;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="DW")
public class DailyWorker extends Worker{

	private int hourlyRate;
	@Override
	public String toString() {
		return "DailyWorker [hourlyRate=" + hourlyRate + ", contractPeriod=" + contractPeriod + "]";
	}
	private int contractPeriod;
	public int getHourlyRate() {
		return hourlyRate;
	}
	public void setHourlyRate(int hourlyRate) {
		this.hourlyRate = hourlyRate;
	}
	public int getContractPeriod() {
		return contractPeriod;
	}
	public void setContractPeriod(int contractPeriod) {
		this.contractPeriod = contractPeriod;
	}
	
	
	
}
