package onetoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BankDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bankId;
	private String acctNumber;
	private String branch;
	public int getBankId() {
		return bankId;
	}
	public BankDetail(int bankId, String acctNumber, String branch) {
		super();
		this.bankId = bankId;
		this.acctNumber = acctNumber;
		this.branch = branch;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public BankDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAcctNumber() {
		return acctNumber;
	}
	public void setAcctNumber(String acctNumber) {
		this.acctNumber = acctNumber;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	 
	
}
