package subclass;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class ITResource {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int resId;
private String name;
public int getResId() {
	return resId;
}
public void setResId(int resId) {
	this.resId = resId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}




}
