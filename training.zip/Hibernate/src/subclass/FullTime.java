package subclass;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name="resId")
public class FullTime extends ITResource{

	private int perHourPay;
	private int duration;
	public int getPerHourPay() {
		return perHourPay;
	}
	public void setPerHourPay(int perHourPay) {
		this.perHourPay = perHourPay;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
}
