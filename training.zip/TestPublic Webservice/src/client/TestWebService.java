package client;

import net.webservicex.GeoIP;
import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;

public class TestWebService {

	public static void main(String args[])
	{
		
		GeoIPService geoService = new GeoIPService();
		GeoIPServiceSoap service = geoService.getGeoIPServiceSoap();
		GeoIP ip = service.getGeoIP("151.101.100.81");
		System.out.println(ip.getCountryName());
		
	}
}
