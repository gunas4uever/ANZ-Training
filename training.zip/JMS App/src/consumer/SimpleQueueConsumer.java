package consumer;

import java.util.concurrent.TimeUnit;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class SimpleQueueConsumer {

	
	private String connectionUrl ="tcp://localhost:61616";
	private ActiveMQConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private Destination destination;
	MessageConsumer consumer;
	
	
	public void before() throws JMSException{
		connectionFactory = new ActiveMQConnectionFactory(connectionUrl);
		connection = connectionFactory.createConnection();
		session = connection.createSession(false,session.AUTO_ACKNOWLEDGE);
		destination =  session.createQueue("testQueue1");
		consumer = session.createConsumer(destination);
		connection.start();
	}
	
	public void run() throws JMSException, InterruptedException{
		consumer.setMessageListener(new ApplMessageListener("consumer1"));
		//connection.start();
	    TimeUnit.MINUTES.sleep(5);
	    connection.close();
		/*while(true){
			Message msg = consumer.receive();
			if(msg instanceof TextMessage){
				TextMessage tm =(TextMessage)msg;
				System.out.println(tm.getText());
			}
		}*/
	}
	
	public void after() throws JMSException
	{
		session.close();
		connection.close();
	}
			
	public static void main(String[] args) throws InterruptedException
	{
		SimpleQueueConsumer obj = new SimpleQueueConsumer();
		try {
			obj.before();
			obj.run();
			obj.after();
		} catch (JMSException e) {
					e.printStackTrace();
				}
			} 
}
