package consumer;

import java.util.concurrent.TimeUnit;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class SimpleTopicConsumer {
	
	private String connectionUrl = "tcp://localhost:61616";
	private ActiveMQConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private Destination destination;

public void before() throws JMSException
{
	connectionFactory = new ActiveMQConnectionFactory(connectionUrl);
	connection = connectionFactory.createConnection();
	// createSession(isTransactionRequired,acknowledgmentMode)
	session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
	destination = session.createTopic("testTopic");
	
}


public void run() throws InterruptedException 
{
	MessageConsumer consumer;
	try {
		
		consumer = session.createConsumer(destination);
		consumer.setMessageListener(new ApplMessageListener("consumer1"));
		
		/*consumer = session.createConsumer(destination);
		consumer.setMessageListener(new ApplMessageListener("consumer2"));*/
		
		connection.start();
	    TimeUnit.MINUTES.sleep(5);
		//connection.stop();
		//consumer.close();
	} catch (JMSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

public void after() throws JMSException
{
	session.close();
	connection.close();
}
		
public static void main(String[] args) throws Exception
{
	SimpleTopicConsumer obj = new SimpleTopicConsumer();
	try {
		obj.before();
		obj.run();
		obj.after();
	} catch (JMSException e) {
				e.printStackTrace();
			}
		} 
}
