package consumer;

import java.util.concurrent.TimeUnit;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicSubscriber;

import org.apache.activemq.ActiveMQConnectionFactory;

public class DurableSubscriber {

	private String connectionUrl ="tcp://localhost:61616";
	private ActiveMQConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private Topic topic;

	
	public void before() throws JMSException
	{
		connectionFactory = new ActiveMQConnectionFactory(connectionUrl);
		connection = connectionFactory.createConnection();
		connection.setClientID("abc");
		connection.start();
		session = connection.createSession(false, session.AUTO_ACKNOWLEDGE);
		topic =  session.createTopic("testDurableTopic");
		
	}
	

	public void run() throws Exception {
	TopicSubscriber durableSubscriber = 
			session.createDurableSubscriber(topic, "testSubscriber");
	
	durableSubscriber.setMessageListener(new ApplMessageListener("teat 1"));
	TimeUnit.MINUTES.sleep(5);
	connection.stop();
	durableSubscriber.close();
		
	}
	public void after() throws JMSException
	{
		session.close();
		connection.close();
	}
	public static void main(String[] args) throws Exception  {
		DurableSubscriber obj = new DurableSubscriber();
		try {
			obj.before();
			obj.run();
			obj.after();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
}
