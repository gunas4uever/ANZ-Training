package consumer;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class ApplMessageListener implements  MessageListener{

	String message = null;
	public ApplMessageListener()
	{
		
	}
	public ApplMessageListener(String message){
		this.message= message;
	}
	public void onMessage(Message message1)
	{
		if(message1 instanceof TextMessage)
		{
			try {
				String msg = ((TextMessage)message1).getText();
				System.out.println(message + " received " + msg);
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}				
		}
	}
}
