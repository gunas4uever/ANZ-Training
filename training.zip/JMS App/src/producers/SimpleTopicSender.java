package producers;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class SimpleTopicSender {

	
	private String connectionUrl = "tcp://localhost:61616";
	private ActiveMQConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private Destination destination;
	
	
	public void before() throws JMSException
	{
		connectionFactory = new ActiveMQConnectionFactory(connectionUrl);
		connection = connectionFactory.createConnection();
		// createSession(isTransactionRequired,acknowledgmentMode)
		session = connection.createSession(false,Session.CLIENT_ACKNOWLEDGE);
		destination = session.createTopic("testDurableTopic");
		connection.start();
	}
	
	public void run() throws JMSException
	{
		MessageProducer producer  = session.createProducer(destination);
		TextMessage message = session.createTextMessage("hello jms topic");
		
		/*MessageProducer producer1  = session.createProducer(destination);
		TextMessage message1 = session.createTextMessage("hello jms topic1");*/
		
		
		message.setIntProperty("id", 1);
		producer.send(message);
		/*message1.setIntProperty("id", 2);
		producer1.send(message);*/
		
		producer.close();
		//producer1.close();
	}
	public void after() throws JMSException
	{
		session.close();
		connection.close();
	}

	public static void main(String[] args)  {
		SimpleTopicSender obj = new SimpleTopicSender();
		try {
			obj.before();
			obj.run();
			obj.after();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
