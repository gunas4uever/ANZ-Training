package producers;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class SimpleQueueSender {

	
	private String connectionUrl ="tcp://localhost:61616";
	private ActiveMQConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private Destination destination;
	
	
	
	public void before() throws JMSException{
		connectionFactory = new ActiveMQConnectionFactory(connectionUrl);
		connection = connectionFactory.createConnection();
		session = connection.createSession(false, session.AUTO_ACKNOWLEDGE);
		destination =  session.createQueue("testQueue1");
	}
	
	public void run() throws JMSException{
		MessageProducer producer = session.createProducer(destination);
		TextMessage message = session.createTextMessage("hello jms");
		message.setIntProperty("id", 1);
		
		producer.send(message);
		producer.close();
	}
	
	public void after() throws JMSException
	{
		session.close();
		connection.close();
	}
			
	public static void main(String[] args)
	{
		SimpleQueueSender obj = new SimpleQueueSender();
		try {
			obj.before();
			obj.run();
			obj.after();
		} catch (JMSException e) {
					e.printStackTrace();
				}
			} 
}
