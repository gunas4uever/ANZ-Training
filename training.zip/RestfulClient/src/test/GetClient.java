package test;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.moxy.json.MoxyJsonFeature;

import domain.Message;

public class GetClient {

	
	public static void main(String[] args) {
		
		
		// Create a client object
		
		ClientConfig config = new ClientConfig();
		config.register(MoxyJsonFeature.class);
		
		Client client = ClientBuilder.newClient(config);
		
		
		// build a web target  "http://localhost:8090/RestApp/rest/messages
		
		WebTarget webTarget = client.target("http://localhost:8083/Restful/restnow").path("messages");
		
		// create invocation builder, and call get()
		
		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
		invocationBuilder.accept(MediaType.APPLICATION_JSON);
		Response resp = invocationBuilder.get();
			
		
		
		List<Message> msges = resp.readEntity(new GenericType<List<Message>>(){});
		
		
		System.out.println("List of messages read "+msges);
		System.out.println("status returned is "+resp.getStatus());
		
		
		
	}
}
