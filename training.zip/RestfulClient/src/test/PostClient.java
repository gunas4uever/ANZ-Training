package test;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.moxy.json.MoxyJsonFeature;

import domain.Message;

public class PostClient {
	public static void main(String[] args) {
		ClientConfig config = new ClientConfig();
		config.register(MoxyJsonFeature.class);
		
		Client client = ClientBuilder.newClient(config);
		
		
		// build a web target  "http://localhost:8090/RestApp/rest/messages
		
		WebTarget webTarget = client.target("http://localhost:8083/Restful/restnow").path("messages");
		
		// create invocation builder, and call get()
		
		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);	
		
		Message msg = new Message(2,"asd1","asd1");
		invocationBuilder.post(Entity.entity(msg, MediaType.APPLICATION_JSON));
	}
	
	
}
