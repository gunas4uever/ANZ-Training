package test;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.moxy.json.MoxyJsonFeature;

import domain.Message;

public class PUTClient {
public static void main(String[] args) {
		
		
		// Create a client object
		
		ClientConfig config = new ClientConfig();
		config.register(MoxyJsonFeature.class);
		
		Client client = ClientBuilder.newClient(config);
		
		
		// build a web target  "http://localhost:8090/RestApp/rest/messages
		
		WebTarget webTarget = client.target("http://localhost:8083/Restful/restnow").path("messages").path("2");
		
		// create invocation builder, and call get()
		
		Invocation.Builder invocationBuilder = webTarget.request();
				
		Message msg = new Message(2,"dfg234","asd234");
		Response resp = invocationBuilder.put(Entity.entity(msg, MediaType.APPLICATION_JSON));
		
	
		System.out.println("msg updated "+msg);
		System.out.println("status returned is "+resp.getStatus());
		
		
		
	}
}
