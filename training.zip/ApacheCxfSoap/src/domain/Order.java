package domain;

public class Order {

	 private String customerId;
	 private String itemId;
	 private int qty;
	 private double price;
	 
	 
	 
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(String customerId, String itemId, int qty, double price) {
		super();
		this.customerId = customerId;
		this.itemId = itemId;
		this.qty = qty;
		this.price = price;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	 
	
}
