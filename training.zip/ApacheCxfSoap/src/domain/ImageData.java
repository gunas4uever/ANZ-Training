package domain;

import java.awt.Image;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ImageData")
@XmlAccessorType(XmlAccessType.FIELD)
public class ImageData {

	protected String name;
	
	@XmlMimeType("application/octet-stream")
	protected Image myImage;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Image getMyImage() {
		return myImage;
	}

	public void setMyImage(Image myImage) {
		this.myImage = myImage;
	}

	 

}
