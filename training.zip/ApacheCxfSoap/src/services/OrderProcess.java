package services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import domain.ImageData;
import domain.Order;

@WebService
public interface OrderProcess {

	@WebMethod
	String processOrder(Order o);
	
	void saveOrderImage(ImageData d);
}
