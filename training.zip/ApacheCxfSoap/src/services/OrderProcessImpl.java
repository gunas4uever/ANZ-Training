package services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import domain.ImageData;
import domain.Order;
@WebService
public class OrderProcessImpl implements OrderProcess {

	@WebMethod
	public String processOrder(Order o) {
		// TODO Auto-generated method stub
		return "ORD12344";
	}

	@Override
	public void saveOrderImage(ImageData d) {
		// TODO Auto-generated method stub
		
		System.out.println(d.getMyImage().getHeight(null));
		
	}

}
