import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.proj.model.Books;
import com.proj.model.Reviews;
import com.proj.service.BooksService;

import core.Department;
import core.HelloBean;

public class TestHelloBean {
	public static void main(String args[]){
		/*ApplicationContext context = new AnnotationConfigApplicationContext(HelloWorldConfig.class);
		HelloWorld helloworld = context.getBean(HelloWorld.class);
		helloworld.setMessage("Hello World");
		helloworld.getMessage();*/
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		/*HelloBean hello = context.getBean("hello", HelloBean.class);
		hello.sayHello();
		
		HelloBean hello1 = (HelloBean) context.getBean("helloBean");
		hello1.sayHello();*/
		
		//HelloBean person = (HelloBean) context.getBean("helloperson");
		//person.personDetails();
		
		//Person p = (Person) context.getBean("pf");
		//System.out.println(p.getId() +" "+p.getName());
		
		/*Department d = (Department) context.getBean("department");
		d.printNames();*/
		
		/*Employee empsingleton = (Employee) context.getBean("employeesingleton");
		empsingleton.printMealCount();
		Employee emp1singleton = (Employee) context.getBean("employeesingleton");
		emp1singleton.printMealCount();
		Employee emp2singleton = (Employee) context.getBean("employeesingleton");
		emp2singleton.printMealCount();
		
		Employee empprototype = (Employee) context.getBean("employeeprototype");
		empprototype.printMealCount();
		Employee emp1prototype = (Employee) context.getBean("employeeprototype");
		emp1prototype.printMealCount();
		Employee emp2prototype = (Employee) context.getBean("employeeprototype");
		emp2prototype.printMealCount();*/
		
		
		BooksService bs = (BooksService)context.getBean("BooksService");
		Books b  = new Books();
		List<Reviews> l = new ArrayList<Reviews>();
		b.setAuthor("GUn");b.setBookId("2");b.setLanguage("Tamil");b.setNoOfPages(25);b.setTitle("Gun");
		b.setStatus("y");
	
		Reviews  r = new Reviews();
		r.setId("2");r.setBookid("2");r.setComments("ggoo2");r.setRating(2);l.add(r);
		r = new Reviews();
		r.setId("2");r.setBookid("2");r.setComments("ohhhhhh2");r.setRating(1);l.add(r);
		
		b.setReviews(l);
		bs.create(b);
		
		bs.retrieve(b);
		
	}
}
