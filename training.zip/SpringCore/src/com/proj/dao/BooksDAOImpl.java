package com.proj.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.proj.model.Books;
import com.proj.model.Reviews;

@Repository("BooksDAO")
public class BooksDAOImpl implements BooksDAO{
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public BooksDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void update(Books b) {
		
		
	}

	
	@Override
	public void delete(Books b) {
		
		
	}

	@Override
	public List getAllBooks() {
		String query = "select * books";
		return jdbcTemplate.queryForList(query);
	}

	@Override
	public void insert(Books b) {
		String query = "insert into books(BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR ) "
				+ "values(?,?,?,?,?,?)";
		
		String query1 = "insert into REVIEWS(ID, RATING, COMMENTS, BOOKID ) values(?,?,?,?)";
		jdbcTemplate.update(query,  new Object[] { b.getBookId(),b.getTitle(),b.getLanguage(),b.getNoOfPages(),
				b.getStatus(),b.getAuthor()});
		List<Reviews> l = b.getReviews();
		for(Reviews r : l)
		jdbcTemplate.update(query1,  new Object[] { r.getId(),r.getRating(),r.getComments(),r.getBookid()});
		
	}

	@Override
	public List<Books> retrieve(Books b) {
		String query = "select * from books b inner join reviews r ON r.bookid =b.bookid  where bookid = ?";
		//return jdbcTemplate.qu
		return null;
	}

}
