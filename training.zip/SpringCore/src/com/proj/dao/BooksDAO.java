package com.proj.dao;

import java.util.List;

import com.proj.model.Books;

public interface BooksDAO {
	void update(Books b);
	void insert(Books b);
	void delete(Books v);
	List<Books> getAllBooks();
	List<Books> retrieve(Books b);
}
