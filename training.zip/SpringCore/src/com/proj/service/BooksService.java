package com.proj.service;

import java.util.List;

import com.proj.model.Books;

public interface BooksService {
	void create(Books v);
	void update(Books v);
	void delete(Books v);
	List<Books> retrieve(Books b);
}
