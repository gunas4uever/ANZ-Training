package com.proj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.dao.BooksDAO;
import com.proj.model.Books;

@Service("BooksService")
public class BooksServiceImpl implements BooksService{

	@Autowired
	private BooksDAO booksDAO;
	
	 

	public BooksDAO getBooksDAO() {
		return booksDAO;
	}

	public void setBooksDAO(BooksDAO booksDAO) {
		this.booksDAO = booksDAO;
	}

	@Override
	public void create(Books v) {
		booksDAO.insert(v);
		
	}

	@Override
	public void update(Books v) {
		booksDAO.update(v);
		
	}

	@Override
	public void delete(Books v) {
		booksDAO.delete(v);	
	}

	public List<Books> retrieve(Books b){
		return booksDAO.retrieve(b);	
	}
}
