package aspects;

import org.springframework.beans.factory.BeanNameAware;


public class SimpleCache implements BeanNameAware{
	private String name;
	
	@Override
	public void setBeanName(String beanName) {
		name = beanName;
	}
}
