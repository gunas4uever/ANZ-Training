package aspects;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class PropertyChangeTracker {
	private Logger logger = Logger.getLogger(getClass());
	
	@Before("execution(void set*(*))")
	public void trackChange(){
		logger.info("property about to change..");
	}
}
