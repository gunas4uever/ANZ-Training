package aspects;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAOP {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("application-config.xml");
		//PropertyConfigurator.configure("log4j.properties");
		SimpleCache cache = (SimpleCache) context.getBean("cache-A");
		cache.setBeanName("venky");

	}

}
