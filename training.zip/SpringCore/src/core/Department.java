package core;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Department {
	@Autowired
	private List<Employee> employees;
	@Autowired
	private Employee empA;
	@Autowired
	private Employee empB;
	@Autowired
	private Employee empC;

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	public Employee getEmpA() {
		return empA;
	}

	public void setEmpA(Employee empA) {
		this.empA = empA;
	}

	public Employee getEmpB() {
		return empB;
	}

	public void setEmpB(Employee empB) {
		this.empB = empB;
	}

	public Employee getEmpC() {
		return empC;
	}

	public void setEmpC(Employee empC) {
		this.empC = empC;
	}

	public void calculateAverageSalary(){
		int noOfEmployees = 0;
		double totalSalary = 0;
		double averageSalary = 0;
		for(Employee emp:employees){
			noOfEmployees++;
			totalSalary = totalSalary+emp.getSalary();
			averageSalary = totalSalary/noOfEmployees;
		}
		System.out.println("average salary:"+averageSalary);
	}
	
	public void printNames(){
		System.out.println("empA name:"+empA.getName());
		System.out.println("empB name:"+empB.getName());
		System.out.println("empC name:"+empC.getName());
	}
}
