package core;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class HelloBean {
	 public String name;
	 public Person person;

	 public HelloBean(String name) {
		 super();
		this.name=name;
	}
	 
	public HelloBean(){
		super();
	}
	 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void sayHello(){
		System.out.println("Hello:"+name);
	}

	public void setPerson(Person person) {
		this.person = person;
	}
	
	public void personDetails(){
		System.out.println("person Id:"+person.getId());
		System.out.println("person Name:"+person.getName());
	}
}
