package core;

import org.springframework.beans.factory.FactoryBean;

public class PersonFactory implements FactoryBean<Person>{

	@Override
	public Person getObject() throws Exception {
		Person p = new Person();
		p.setId(10);
		p.setName("factoryTest");
		return p;
	}

	@Override
	public Class getObjectType() {
		// TODO Auto-generated method stub
		return Person.class;
	}

	@Override
	public boolean isSingleton() {
		// TODO Auto-generated method stub
		return false;
	}

}
