package core;

public class MySingleton {
	private static MySingleton singleton = new MySingleton();
	
	private MySingleton(){
		super();
	}
	
	public MySingleton getInstance(){
		return new MySingleton();
	}
	
	
}
