package core;

import org.springframework.context.annotation.Import;

@Import(ConfigA.class)
public class ConfigB {

}
