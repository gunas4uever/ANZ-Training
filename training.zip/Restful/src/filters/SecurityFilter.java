package filters;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.glassfish.jersey.internal.util.Base64;

@Provider
public class SecurityFilter implements ContainerRequestFilter {

	@Override
	public void filter(ContainerRequestContext req) throws IOException {
		String userName ="";
		String password ="";
		
		if(req.getUriInfo().getPath().contains("secure"))
		{
			List<String> authHeader = req.getHeaders().get("Authorization");
			
			if(authHeader != null && authHeader.size()>0){
				String authToken = authHeader.get(0);
				authToken = authToken.replaceFirst("Basic ", "");
				byte[] encode = Base64.encode(authToken.getBytes());
				String decodedString = Base64.decodeAsString(encode);
				StringTokenizer token = new StringTokenizer(decodedString, ":");
				if(token.hasMoreTokens()){
					userName = token.nextToken();
					if(token.hasMoreTokens()){
						password = token.nextToken();
					}
				}
				System.out.println(" userName  : " + userName);
				System.out.println(" password  : " + password);
				if("abc".equals(userName) && "abc".equals(password) ){
					return;
				}
				
				
			}
			
			Response unauthorized = Response.status(Response.Status.UNAUTHORIZED)
					.entity("User cannot access the resource").build();
			req.abortWith(unauthorized);
		}
		
	}

}
