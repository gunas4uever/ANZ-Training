package resources;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Solution1 
{
		   public static void main(String[] args) throws Exception
		   {
		        BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		        List<String> l = new ArrayList<String>();
		        List<String> ll = new ArrayList<String>();
		        Set<Integer> s = new LinkedHashSet<Integer>();
		        List<String> d = new ArrayList<String>();
		        String[] temp = bfr.readLine().split(" ");
		        int N = Integer.parseInt(temp[0]);
		        int I = Integer.parseInt(temp[1]);

		        for(int i = 0; i < I; i++){
		            temp = bfr.readLine().split(" ");
		            int a = Integer.parseInt(temp[0]);
		            int b = Integer.parseInt(temp[1]);
		          // Store a and b in an appropriate data structure of your choice

		            l.add(a+"_"+b); 
		            s.add(a);s.add(b);
		            
		        }
		        if(s.size() != N){
		        	for(int i = 0; i < N; i++)
		        		s.add(i);
		        }
		        Map<String, List<String>> mm = new LinkedHashMap<String, List<String>>();
		        for(String lll : l){
		        	String as[] = lll.split("_");
		        	 
		        	for(String ss : l){
		        		if(!ss.equals(lll) && ss.startsWith(as[0]+"_")){
		        			//if((as[1].compareTo(ss.split("_")[1])) == -1 )
		        			
		        			/*if(!(mm.containsKey(as[0]) || mm.containsValue(ss.split("_")[1])) &&
		        					!(mm.containsKey(as[0]) || mm.containsValue(ss.split("_")[1])))
		        			{
		        				if(!mm.containsKey(as[1]))
		        					mm.get(as[1]).add(ss.split("_")[1]);
		        				else
		        					mm.put(as[1], ss.split("_")[1]);*/
		        			System.out.println("  --- " + d.contains(as[1]+"_"+ss.split("_")[1]) +" @@@@@ " +
		        					d.contains(ss.split("_")[1]+"_"+as[1]));
		        			if(!(d.contains(as[1]+"_"+ss.split("_")[1])) && !(d.contains(ss.split("_")[1]+"_"+as[1])))
		        				 d.add(as[1]+"_"+ss.split("_")[1]);
		        			//}
		        			
		        		}
		        		
		        	}
		        }
		        l.addAll(d);
		        
		        long combinations = 0;

		        // Compute the final answer - the number of combinations
		        Object[] array = s.toArray();

		        for(int i=0; i<array.length; i++)
		        {
		            for(int j=1; j<array.length; j++)
		            {
		            	if((array[i] != array[j]) &&  ((int)array[i]< (int)array[j]))
		            		ll.add(array[i] +"_"+array[j]);
		            }
		        }
		        Set<String> hashset = new HashSet<String>(ll);

		        for(int i = 0; i < l.size(); i++) 
		        {
		            if(hashset.contains(l.get(i))) 
		            {
		            	hashset.remove(l.get(i));
		            }
		        }
		        combinations = hashset.size();
		        System.out.println(combinations);
		        
		        for(String sss : hashset){
		        	System.out.println(sss);
		        }
		        }
		}
