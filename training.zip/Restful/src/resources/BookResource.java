package resources;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;

import domain.Book;
import exception.DataNotFoundException;
import service.BookService;
import service.BookServiceImpl;


@Path("/book/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {
	
	
	private BookService bookService = new  BookServiceImpl();
	
	/*@Autowired
	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}*/

	@GET
	public List<Book> getBookList()
	{
		System.out.println("getting book lists from DB ...");
		List<Book> bookList = new  BookServiceImpl().getBookList();
		return bookList;
	}
	
	@GET
	@Path("/{bookId}")
	public Book getBook(@PathParam("bookId") String bookId, @Context UriInfo uriInfo)
	{
		
		System.out.println("getting book from DB ...");
		Book book = new  BookServiceImpl().getBook(bookId);
		if(book== null )
			throw new DataNotFoundException(" Book with id "+ bookId + " does not exists");
		//Book book1 = new Book(book.getBookId(), book.getTitle(),book.getLanguage(),book.getNoOfPages(),book.getStatus(),book.getAuthor());
		//book1.addLink(getUriForSelf(uriInfo, book1), "SELF");
		return book;
	}
	
	private String getUriForSelf(UriInfo uriInfo, Book book1) {
		// TODO Auto-generated method stub
		return uriInfo.getBaseUriBuilder().path(BookResource.class)
				.path(String.valueOf(book1.getBookId())).build().toString();
	}

	@POST
	public Response createBook(Book book,@Context UriInfo uriInfo)
	{
		
		new  BookServiceImpl().createBook(book);
		System.out.println(" inserted book in table ...");
		URI uri = uriInfo.getAbsolutePathBuilder().path(book.getBookId()).build();
		
		 //return Response.status(Status.CREATED).entity(msg1).build();
		return Response.created(uri).entity(book).build();
		
	}
	
	//@Path("/{bookId}")
	@PUT
	public void updateBook( Book book)
	{
		
		//return new Message(id,msg.getName(), msg.getAuthor());
		//Book book = new Book(b.get, "indid"," french","700", "AAAAAAA" );
		new  BookServiceImpl().updateBook( book);
		 System.out.println(" updated book ...");
		
	}
	
	@Path("/{bookId}")
	@DELETE
	public void deleteMessage(@PathParam("bookId") String bookId)
	{
		new  BookServiceImpl().deleteBook(bookId);		
		System.out.println(" deleted book ...");
	} 


	
}
