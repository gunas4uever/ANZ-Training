package resources;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import context.MessageFilterBean;
import domain.Message;
import exception.DataNotFoundException;

@Path("/messages")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MessageResource {
	
	@GET
	@Path("/messageFilter")	
	public List<Message> getFilteredMessages(@BeanParam MessageFilterBean filterBean )
	{
		System.out.println("message filtered ...");
		System.out.println(filterBean.getAuthor());
		System.out.println(filterBean.getOffset());
		System.out.println(filterBean.getPageSize());
		return Arrays.asList(new Message(1,"msg1" , "abc"),
				new Message(2,"msg2" , "def"));
		
	}
	
	
	@Path("/{messageId}/comments/")
	public CommentResource getAllComments(){
		
		System.out.println("::::  in getAllComments()");
		return new CommentResource();
	}
	
	@GET
	public List<Message> getMessages()
	{
		System.out.println("message retreved ...");
		return Arrays.asList(new Message(1,"msg1" , "abc"),
				new Message(2,"msg2" , "def"));
		
	}
	
	@GET
	@Path("/{messageId}")	
	public Message 
	getMessage(@PathParam("messageId") int id, @Context UriInfo uriInfo)
	{
		if(id == 5){
			throw new DataNotFoundException(" message with id "+ id + " does not exists");
		}
		System.out.println("message fetched ...");
		Message msg = new Message(id,"msg1 "+id , "abc "+id);
		
		msg.addLink(getUriForSelf(uriInfo, msg), "SELF");
		msg.addLink(getUriForComments(uriInfo, msg), "COMMENTS");
		
		return msg;
		
	}
	
	@POST
	public Response postMessage(Message msg, @Context UriInfo uriInfo)
	{
		System.out.println("message created ...");
		Message msg1 = new Message(msg.getId()+1, "msg1 "+msg.getId()+1 , "abc "+msg.getId()+1);
		String newId =String.valueOf("2");
		URI uri = uriInfo.getAbsolutePathBuilder().path(newId).build();
		
		 //return Response.status(Status.CREATED).entity(msg1).build();
		return Response.created(uri).entity(msg1).build();
		
	}
	
	@Path("/{messageId}")
	@PUT
	public Message updateMessage(@PathParam("messageId") int id, Message msg)
	{
		System.out.println("message updated ...");
		return new Message(id,msg.getName(), msg.getAuthor());
		
	}
	
	@Path("/{messageId}")
	@DELETE
	public void deleteMessage(@PathParam("messageId") int id)
	{
		System.out.println("message deleted ...");
		
	}
	
	
	private String getUriForSelf(UriInfo info, Message msg)
	{
		//http://localhost:8083/Restful/restnow/messages/2
		return info.getBaseUriBuilder().path(MessageResource.class)
		//.path(CommentResource.class,"getAllComments").resolveTemplate("messageId", msg.getId())
		.path(String.valueOf(msg.getId())).build().toString();
		
		
	}
	private String getUriForComments(UriInfo info, Message msg)
	{
		//http://localhost:8083/Restful/restnow/messages/2
		return info.getBaseUriBuilder().path(MessageResource.class).path(MessageResource.class,"getAllComments")
		//.path(CommentResource.class)
		.resolveTemplate("messageId", msg.getId())
		.build().toString();
		
		
	}
	@GET
	@Path("/conditional/{messageId}")
	public Response gteMessage(@PathParam("messageId") int id, @Context Request req){
		CacheControl cc = new CacheControl();
		cc.setMaxAge(86400);
		
		Message msg = new Message(1,"aaa", "aaa565");
		EntityTag eTag = new  EntityTag(msg.hashCode()+"");
		Response.ResponseBuilder rb = req.evaluatePreconditions(eTag);
		//rb = req.evaluatePreconditions(eTag);
		// rb is not null when there is a match,
		//	instruct the client to take obj from cache
			
			if(rb != null)
			{
			
				return 	rb.cacheControl(cc).tag(eTag).status(Status.NOT_MODIFIED).build();
			}
			
			rb = Response.ok(msg).cacheControl(cc).tag(eTag);
			
			return rb.build();
		
	}
	
}
