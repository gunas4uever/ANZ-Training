package resources;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

class Student implements Comparable{
   private int token;
   private String fname;
   private double cgpa;
   public Student(int id, String fname, double cgpa) {
      super();
      this.token = id;
      this.fname = fname;
      this.cgpa = cgpa;
   }
   public int getToken() {
      return token;
   }
   public String getFname() {
      return fname;
   }
   public double getCgpa() {
      return cgpa;
   }
    
    
    
       public int compareTo(Object a)
       {
           if(this.getCgpa() != ((Student)a).getCgpa()){
               return Double.compare(((Student)a).getCgpa(), this.getCgpa());
           }
           else
           {
               if(!this.getFname().equals(((Student)a).getFname())){
                   return this.getFname().compareTo(((Student)a).getFname());
               }
               else{
                   return this.getToken() - ((Student)a).getToken();
               }
           }
   }
}


 


public class Solution {

    public static void main(String[] args) {
      Scanner in = new Scanner(System.in);
      int totalEvents = Integer.parseInt(in.nextLine());
      PriorityQueue<Student>  queue = new PriorityQueue<Student>();
      while(totalEvents>0){
         String event = in.next();
       
          if(event.equals("ENTER")){
              String b =  in.next();
              Double c = new Double(in.next());
              int a = Integer.parseInt(in.next());
              Student s = new Student( a,b, c);
              queue.add(s);
          }
          
          if(event.equals("SERVED")){
              if(!queue.isEmpty()){
                  queue.poll();
              }
          }
         totalEvents--;
      }
        
      while ( ! queue.isEmpty()) {
         // Student s = queue.remove();
          System.out.println(queue.poll().getFname());
      }
     
    }
}
