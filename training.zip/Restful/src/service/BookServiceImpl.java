package service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import dao.BookDAO;
import dao.BookDAOImpl;
import domain.Book;

//@Service
//@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class BookServiceImpl implements BookService{

	
	//@Autowired
	private BookDAO bookDAO = new BookDAOImpl();
	
	 

	/*public void setBookDAO(BookDAO bookDAO) {
		this.bookDAO = bookDAO;
	}*/

	@Override
	public void insert(Book b) {
		new BookDAOImpl().insert(b);	
	}

	@Override
	public List<Book> getBookList() {
		return new BookDAOImpl().getBookList();	
	
		
	}

	@Override
	public Book getBook(String bookId) {
		// TODO Auto-generated method stub
		return new BookDAOImpl().getBook(bookId);
	}

	@Override
	public void createBook(Book book) {
		// TODO Auto-generated method stub
		new BookDAOImpl().createBook(book);
	}

	@Override
	public void updateBook( Book book) {
		// TODO Auto-generated method stub
		new BookDAOImpl().updateBook(book);
	}

	@Override
	public void deleteBook(String bookId) {
		// TODO Auto-generated method stub
		new BookDAOImpl().deleteBook(bookId);
	}

	 

}
