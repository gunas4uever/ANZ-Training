package domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.eclipse.persistence.oxm.annotations.XmlInverseReference;

@Entity
public class Review {

	@Id
	private String reviewId;
	private String rating;
	private String comments;
	@ManyToOne
	@JoinColumn(name="bookId")
	@XmlInverseReference(mappedBy="reviews")
	private Book book ;
	 
	
	
	
	
	
	
	
	
	public String getReviewId() {
		return reviewId;
	}
	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Review(String reviewId, String rating, String comments, Book book) {
		super();
		this.reviewId = reviewId;
		this.rating = rating;
		this.comments = comments;
		this.book = book;
	}
	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", rating=" + rating + ", comments=" + comments + ", book=" + book.getBookId() + "]";
	}
	 
	
}
