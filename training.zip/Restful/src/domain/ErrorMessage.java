package domain;

public class ErrorMessage {

	private String errorMessage;
	private int errCode;
	public ErrorMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ErrorMessage(String errorMessage, int errCode, String documentation) {
		super();
		this.errorMessage = errorMessage;
		this.errCode = errCode;
		this.documentation = documentation;
	}
	private String documentation;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public int getErrCode() {
		return errCode;
	}
	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}
	public String getDocumentation() {
		return documentation;
	}
	public void setDocumentation(String documentation) {
		this.documentation = documentation;
	}
}
