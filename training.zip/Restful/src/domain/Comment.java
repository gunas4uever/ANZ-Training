package domain;

public class Comment 
{

	 private String comment;
	 public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comment(String comment, int commentId, String author) {
		super();
		this.comment = comment;
		this.commentId = commentId;
		this.author = author;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	private int commentId;
	 private String author;
	 
	
}
