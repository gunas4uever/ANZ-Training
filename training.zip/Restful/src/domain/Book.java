package domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Book")
public class Book {
	@Id  
	private String  bookId;
	@NotNull 
	private String title;
	@NotNull  
	private String author;
	@NotNull  
	private String language;
	@NotNull  
	private String  noOfPages;
	

	@NotNull    
	private String status;
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="book")
	private List<Review> reviews = new ArrayList<Review>();
	
	//private List<Link> links = new ArrayList<Link>();
	
public Book(){}
	
	public Book(String bookId, String title, String language, String noOfPages, String status, String author) {
		 this.bookId=bookId;
		 this.title=title;
		 this.language=language;
		 this.noOfPages=noOfPages;
		 this.status=status;
		 this.author=author;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getNoOfPages() {
		return noOfPages;
	}

	public void setNoOfPages(String noOfPages) {
		this.noOfPages = noOfPages;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Review> getReviews() {
		return reviews;
	}

	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}
	
	/*public List<Link> getLinks() {
		return links;
	}
	public void setLinks(List<Link> links) {
		this.links = links;
	}
	public void addLink(String url, String desc){
		Link link = new Link(url, desc);
		links.add(link);
	}*/

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + ", language=" + language
				+ ", noOfPages=" + noOfPages + ", status=" + status + ", reviews=" + reviews + "]";
	}
	
	 	 
	 

	 
}