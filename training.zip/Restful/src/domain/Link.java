package domain;

public class Link {

	private String link;
	private String desc;
	public String getLink() {
		return link;
	}
	public Link(String link, String desc) {
		super();
		this.link = link;
		this.desc = desc;
	}
	public Link() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
