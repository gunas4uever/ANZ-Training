package context;

import javax.ws.rs.QueryParam;

public class MessageFilterBean {

	private @QueryParam("author") String author;
	private @QueryParam("offset") int offset;
	private @QueryParam("pageSize") String pageSize;
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	public String getPageSize() {
		return pageSize;
	}
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	
	
	
}
