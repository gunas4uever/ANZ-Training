package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import domain.Book;

//@Repository
public class BookDAOImpl implements BookDAO{
	 
/*private JdbcTemplate jdbcTemplate;
	
@Autowired
	public BookDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}*/
	//@Autowired
	 private SessionFactory factory = new Configuration().configure().buildSessionFactory();;
	
	@Override
	public void insert(Book b) {

		String query = "insert into books(BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR ) "
				+ "values(?,?,?,?,?,?)";
		
		/*jdbcTemplate.update(query,  new Object[] { b.getBookId(),b.getTitle(),b.getLanguage(),b.getNoOfPages(),
				b.getStatus(),b.getAuthor()});*/
		
	}

	//@Override
	//public List<Book> getRecord(Book b) {
		//String query = "select BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR from books";
		
		//return (List<Book>)jdbcTemplate.query(query,Book.class);
		
		
		
	//}

	 
	public List<Book> getBookList() 
	{
		/*String query="select * from books";
		return (List<Book>)jdbcTemplate.query(query,new BeanPropertyRowMapper(Book.class));*/
		Session session = factory.openSession();		
		session.beginTransaction();
		List<Book> l = (List<Book>) session.createQuery("from Book").list();
		session.getTransaction().commit();
		session.close();factory.close();
		return l;
	}

	@Override
	public Book getBook(String bookId)
	{
		/*return (Book)jdbcTemplate.query("select * from books where bookid=?", new Object[]{bookId},
				new BeanPropertyRowMapper(Book.class));*/
		Session session = factory.openSession();		
		session.beginTransaction();
		Book l =  (Book) session.get(Book.class, bookId);
		session.getTransaction().commit();
		session.close();factory.close();
		return l;
	}

	@Override
	public void createBook(Book b) {
		/*return (Book)jdbcTemplate.query("insert into books (BOOKID, TITLE, LANGUAGE, NUMBEROFPAGES, STATUS, AUTHOR )"
				+ "values(?,?,?,?,?,?)" , new Object[]{ b.getBookId(),b.getTitle(),b.getLanguage(),b.getNoOfPages(),
						b.getStatus(),b.getAuthor()},	new BeanPropertyRowMapper(Book.class));*/
		Session session = factory.openSession();		
		session.beginTransaction();
		session.saveOrUpdate(b);
		 session.getTransaction().commit();
		session.close();factory.close();
	}

	@Override
	public void updateBook( Book b) {
		/* jdbcTemplate.update("UPDATE  books SET  LANGUAGE = ? where bookid = ?" , 
				new Object[]{b.getLanguage(),b.getBookId()},	new BeanPropertyRowMapper(Book.class));*/
		Session session = factory.openSession();		
		session.beginTransaction();
		session.update(b);  
		 session.getTransaction().commit();
		session.close();factory.close();
	}

	@Override
	public void deleteBook(String bookId) {
		// TODO Auto-generated method stub
		 /*jdbcTemplate.update("DELETE * FROM books  where bookid = ?" , 
				new Object[]{bookId},	new BeanPropertyRowMapper(Book.class));*/
		Session session = factory.openSession();		
		session.beginTransaction();
		Book book = (Book) session.load( Book.class, bookId); 
		
		if (null != book) { session.delete(book); } 
		 session.getTransaction().commit();
			session.close();factory.close();
	}

	 
}
