package dao;

import java.util.List;

import domain.Book;

public interface BookDAO {

	void insert(Book b);

	List<Book> getBookList();

	Book getBook(String bookId);

	void createBook(Book book);

	void updateBook( Book book);

	void deleteBook(String bookId);

	 

}
