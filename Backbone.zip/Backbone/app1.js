var AppView = Backbone.View.extend({
    el: '#container',
    initialize: function () {
        this.render();
     },
   
    render: function () {
        this.$el.html("<h2>Hello Praveen!!!</h2>");
    }
});
var appView = new AppView();