


//--> Class level with 'this'
//--> Object Creations
//--> Properties assignemnts to objects(not class velel, only object lebel)
//--> method calling on top of objects

var MyApp=Backbone.View.extend({

initialize: function () {
    console.log('app Started');
        this.sayHello();
     },

     el:'#d1',
   
    sayHello: function () {
        $('#d2').append('<h2> New data from backbone</h2>');
        this.$el.html("<h2>Hello Gunasekaran!!!</h2>");
    }

});

var obj = new MyApp();




var HomeView = Backbone.View.extend({
      template: '<h1>Home</h1>',
      initialize: function () {
          this.render();
      },
      render: function () {
          this.$el.html(this.template);
      }
  });
  

var AboutView = Backbone.View.extend({
      template: '<h1>About</h1>',
      initialize: function () {
          this.render();
      },
      render: function () {
          this.$el.html(this.template);
      }
  });
  
  var AppRouter = Backbone.Router.extend({
      routes: {          
          '': 'homeRoute',
          'home': 'homeRoute',
          'about': 'aboutRoute',          
      },
      homeRoute: function () {
          var homeView = new HomeView();          
          $("#content").html(homeView.el);
      },
      aboutRoute: function () {
          var aboutView = new AboutView();          
          $("#content").html(aboutView.el);
      }
  });

  var appRouter = new AppRouter();
  //Backbone.history.start();​
  
  
  












