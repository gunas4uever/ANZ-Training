 


$(document).ready(function(){

//alert($("h1").text());

$("#mess").text(" Go to the hell");

//$("li").text('udnis');
//alert($("#destinations > li"));
 $('button').on('click', function() {
        var price = $('<p>From $399.99</p>');
        $('.vacation').after(price);
        $(this).remove();
});

    var box=$('.well');
     $('.btn-danger').click(function(){
         box.hide();   
     });
     $('.btn-primary').click(function(){
        box.show(); 
     });
});

