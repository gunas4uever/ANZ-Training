$(document).ready(function () {
    console.log("---- dom Ready");
    $('.vacation').on('click', 'button', function (e) {
        var vacation = $(this).closest('.vacation');
        var amount = vacation.data('price');
        var price = $(`
    <p>&#8377;${amount} per ticket</p>
     Number of Tickets: <input class='quantity' value='1' type="number"/> <br/>
    <span class='total'>Total Amount:&#8377;${amount}</span>
    `);
        $(this).closest('.vacation').append(price);
        $(this).remove('button');
        // console.log('Amount is '+amount);
    });
    $('.vacation').on('keyup change', '.quantity', function (e) {
        var qua=$(this).val();
        var price = $(this).closest('.vacation').data('price');
       
      $(this).closest('.vacation').find('.total').text(price * qua);
    });

   $('#filters').on('click','.onsale-filter',function(e){
     $('.bg-success').removeClass('bg-success');
    $('.vacation').filter('.onsale').addClass('bg-success');
   });


    $('#filters').on('click','.expiring-filter',function(e){
     $('.bg-success').removeClass('bg-success');
    $('.vacation').filter('.expiring').addClass('bg-success');
   });

   
});