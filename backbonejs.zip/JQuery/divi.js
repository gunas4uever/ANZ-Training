$(document).ready(function () 
{
    
    //var file = $(this).closest('.file');console.log(file)
        //var amount = vacation.data('price');
     
       

   $('#filters').on('click','.doc-filter',function(e){
     //  alert('ffff');
     $('.bg-success').removeClass('bg-success');
    $('.file').filter('.doc').addClass('bg-success');
   });


    $('#filters').on('click','.pdf-filter',function(e){
        //alert('2222');
     $('.bg-success').removeClass('bg-success');
    $('.file').filter('.pdf').addClass('bg-success');
   });

});
