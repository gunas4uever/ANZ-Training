// quiz on functions,constructors
function sessionStarts(){
   function Trainer(name){
       this.name=name;
       this.doTeach=function(){
           console.log(this.name+" is teaching .js");
            var self=this;
        function doLearn(){
           console.log(this.name+" is learning js from  "+self.name);
           
    }   
        return doLearn; 
  } // do teach end
 } // end of Constructor

function Employee(name){
this.name=name;
}

var tr1=new Trainer('Praveen');
var emp1=new Employee('Employee1');
var emp2=new Employee("Employee2");
var learn=tr1.doTeach();
learn.call(emp1);
learn.call(emp2);

} // end of startSession

sessionStarts();