

function order(orderNam){
    console.log("Order Received " + orderNam);
    function process(){
        console.log("Order Processing " + orderNam);
          function display(){
          console.log("Order displayed " + orderNam);
        }return display;
    }return process;
}

var processFun = order('chicken Biryani');
var displayFun=processFun();
displayFun();