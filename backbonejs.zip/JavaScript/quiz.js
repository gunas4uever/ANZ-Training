
function Person(name, age){
    console.log(this);
    this.name = name;
    this.age = age;
    
    sayName=function(){
        console.log("i am " + name);
    }
    sayAge=function(){
        console.log("i am " + age + " old");
    }
    sayName();
    sayAge();
}

var p1= new Person('Guna', 30);
var p2= new Person('Sekar', 27);
 
