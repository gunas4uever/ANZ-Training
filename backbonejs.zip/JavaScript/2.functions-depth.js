
function f1(v1, v2){
    return v1+v2;
}

var result = f1(100,200);

var obj = function(){
    console.log(" --- testt")
}


var emp = function(){
    var n1=19;
    var n2 =1;
    return n1 +n2;
}
 
  var name="gunasekaran";
  person =  {
      name:"guna",
     sayName: function(){
          console.log( "name is " + name);
      }
  }
//   person.sayName();

//    var p = person;
//    person={
//        name:'prakash'
//    }

//   p.sayName();

console.log("sum is " + f1(100,200))//for function with name, u can call before function executes -- created in global context
  
  function f1(n1,n2){
      return n1+n2;
  }
var f2 =f1;
console.log("sum is " + f2(150,200))
  
 console.log("Sum is --> " +employee (10,22));// will be called during execution phase, so u can't call before method
   employee = function (n1,n2){
      return n1+n2;
  }
    
   var eeee = employee;
  console.log("Sum is --> " +eeee(10,2));


  function teach(){
      console.log('teching ...')
      function learn(){
           console.log('learning ...')
            function task(){
           console.log('task... ...')
      }
      return task;
    }
    return learn;
  }
  var learnFunc = teach();
  learnFunc();
  var taskFun = learnFunc();
  taskFun();

  function f(){
      a=100;
  }
// console.log('before ' + a);
  f();
  console.log('after ' + a);