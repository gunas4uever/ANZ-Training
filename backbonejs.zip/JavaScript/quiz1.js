
function Person(name, age) {
    this.name = name;
    this.age = age;
    sayName = function () {
        console.log('i m ' + name);
    }
    sayAge = function () {
        console.log('i m ' + age + " old");
    }
   sayName();
   sayAge();
}
// Person('Abc',100);  // Never invoke constructors without 'new' keyword
var p=new Person('Gunasekaran.P', 100);



var trainer = {
    name:'Nag',    
doTeach: function () {   
     console.log(this.name + " teaching .js");
    var self = this;
    function doLearn() {       
     console.log(this.name+' learning .js from '+self.name);
        }   
     //doLearn();        
var emp = { name: 'CTS' };    
    doLearn.call(emp);     
  }
};

trainer.doTeach();
 var tempTrainer = {
 name: 'Ria' };

 //trainer.doTeach.call(tempTrainer);



function sessionStart() {  
    function Trainer(name) {
       this.name = name;
       this.doTeach = function () {
            console.log(this.name + " teaching .js");
        var self = this;
      function doLearn() {
       console.log(this.name+" learning .js from "+self.name);
    }
      return doLearn;
     }
    }
   
function Employee(name) {
        this.name = name;
    }
   
 var nagTnr = new Trainer('Nag'); 
 // constructor-invocation
    var emp1 = new Employee('Emp1');   
 var emp2 = new Employee('Emp2');
   
 var learn = nagTnr.doTeach(); 
 // method invocation
    
    learn.call(emp1); 
 // call/apply/bind invocation
    learn.call(emp2);
}
sessionStart();  // function-invocation

function outer(a)
{
   function inner(b)
   {
      return b * 2 + a;
   }
   return inner(a)
}
var z = outer(5);console.log(z);


function outer1(a)
{
    this.a=a;
    this.doCal=function(){
   function inner1(b)
   {
      console.log(b * 2 + a);
      return b * 2 + a;
   }   
   return inner1(a)
}
}
new outer1(5).doCal();