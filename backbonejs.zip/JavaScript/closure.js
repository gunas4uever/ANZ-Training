/*
A closurer is a function having access to the parent scope 
even after parent function has closed
why we need?
------------
-->  to abstract any public -behavior of any module
--> while executing fun async, to access the parent scope
     data
*/
function teach(sub){
    console.log('teaching '+sub);
    var notes=sub+' -notes';
    var i=100;
    function learn(){
        console.log(' learning with '+notes);
    }
   function fun(){
        console.log(' i value is '+i);
   }
   //learn();
  // fun();
   console.log('teaching ends');
   return learn;
}// teach context destroyed
var learnFun=teach('java script');
// teach context created with local and arguments
learnFun();
//fun(); --> ref error. xyz fun Parent context closed



// to abstract any public behaviour of any module 
var count=(function init(){
    var count=0;
    function doCount() {
        count++;
    }
    function getCount() {
        return count;
    }
     var obj={
        doCount:doCount,
        getCount:getCount
    }
    return obj;
})();
//var counter=init();  // context for init --> counter
//counter.setCount(); // context on top of init created 


function Person(name, age){
    this.name=name;
    this.age=age;

    Person.prototype.sayName = function(){
        console.log("I m  "+ name);
    }
    Person.prototype.sayAge = function(){
        console.log("I m  "+ age);
    }
}

var p1 = new Person('ria',22);
var p2 = new Person('guna',44);
var p3 = Object.create(p1);



// do IT: Extend Employee with Person
function Employee(name,age,salary){
    Person.call(this,name, age);
    this.salary=salary;
}

Employee.prototype = new Person();

Employee.prototype.saySalary=function(){
console.log('i am getting '+this.salary);
}
 
var emp=new Employee('Nag',34,76456);
 emp.sayName();
 emp.sayAge(); 
emp.saySalary();





function Person1(name){
    this.name=name;
    Person1.prototype.sayName=function(){
        console.log(' i am '+this.name);
    }
}
function Employee1(name,skill){
   Person1.call(this,name);
   this.skill=skill;  
}
Employee1.prototype=new Person1();
Employee1.prototype.saySkill=function(){
    console.log(' I know '+this.skill);
}
var e1=new Employee1('Praveen','Java Script');
e1.sayName();
e1.saySkill();






var person={
_name:'Praveen',
_age:23,
set name(newName){
    console.log('---setting name '+ newName);
    if(newName){
        this._name=newName;
    } // if end
},
set age(newAge){
    console.log('---setting age '+ newAge);
    if(newAge){
        this._age=newAge;
    }
},
get name(){
    console.log('---getting name');
    return this._name;
},
get age(){
    console.log('--getting age');
    return this._age;
}
}; // end of person
person.name='Praveen';
person.age=45;
console.log(person.name);
console.log(person.age);