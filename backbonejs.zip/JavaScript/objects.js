"use strict"
// function f1(){
//     console.log(k);
// }
// var k=87;
// f1();
   
/*
by defaly js objects are configurable, extensible 
and enumurable
*/   
var person={
    name:'Praveen',
    age:32
};
Object.defineProperty(person,'name',{configurable:false,writable:false,enumerable:false});
Object.defineProperty(person,'age',{configurable:false,writable:false,enumerable:false});
person.city='ggg';
Object.preventExtensions(person);
//person.add='56456';
//person.name='James'; -->Error: read only
//person.city='Chennai'; //Error:  extension is disabled

Object.seal(person);
Object.freeze(person);


console.log(new Date().getDate());
 