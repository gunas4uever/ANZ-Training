console.log(" -- data Types")

// var s1="Guna";
// var s2='Guna';
// var s1= 100;

// var n1= 100;
// var n2= 88.89;

// var status2 = true;
// var status1 = false;

// console.log(x); ///prints undefined as it is
// var x =200;
// console.log("name is : " +name);//checks local scope then global scope and then in parent i.e. window scope
// console.log(name1);

// COMPLEX DATATYPES/REFERENCES
var person1 = null;
var person = new Object;
//dot operator
person.name="Gunasekaran"
person.age=30;
person.flag= false;

//literal style
var emp ={
    eid:20,
    ename :'Gunasekaran',
    age:35
};
emp['eid'] =1024
 

var emp ={
    eid:20,
    'emp-name' :'prasad', // special chars should be in single/double quotes
    age:35
};

var arr =new Array();
arr.push('guna');arr.push("sekar");
arr.push(11);

var ss = new RegExp("\\d{4}-\\d{4}-\\d{4}-\\d{4}");
 console.log(ss.test("1234-1234-1234-1234"));

var ssn = /\d{3}-\d{4}-\d{2}-\d{4}/;
