


var Trainer={
    name:'Gunasekaran'
}
var teachService={
    doTeach:function(){
        console.log(this.name+ ' is teaching .js');
    }
};

var btn = document.querySelector('.btn-primary');
btn.addEventListener('click', teachService.doTeach.bind(Trainer));


function init(){
    var count=0;
    function doCount() {
        count++;
    }
    function getCount() {
        return count;
    }
     return {
        doCount:doCount,
        getCount:getCount
    }
}
var counter=init();


function Person(name,age)
{
    this.name=name;
    this.age=age;
    var self=this;
    
    var i=1000;
    function abc()
    {
        console.log("I is "+i++);
    }
    function incAge(){
        self.age++;
        console.log('i am '+self.name+" --> Age "+self.age);
    }
    //setInterval(incAge,4000);
    //setInterval(abc,1000);
}
var p=new Person('Gunasekaran',0);


